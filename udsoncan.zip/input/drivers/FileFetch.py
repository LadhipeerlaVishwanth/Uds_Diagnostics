import logging
import os
import shutil
from drivers import oled_display

class USBTransfer(oled):
        def __init(self,oled):
                self.oled = oled
                self.usb_mount_path = "/media/mobase/"
        def _display(self, message):
                if self.oled:
                        self.oled.display_centered_text(message)
                        
def fetch_testcase_and_config_from_usb(self, oled):
    self._display("Looking for USB...")
    logging.info("Checking USB mount path...")

    try:
        for device in os.listdir(self.usb_mount_path):
            usb_path = os.path.join(self.usb_mount_path, device)
            if os.path.isdir(usb_path):
                logging.info(f"Found USB: {usb_path}")
                self._display("USB found.\nSearching files...")

                # Walk through all folders in USB
                copied = False
                for root, dirs, files in os.walk(usb_path):
                    if "testcase.txt" in files:
                        testcase_src = os.path.join(root, "testcase.txt")
                        testcase_dst = "/home/mobase/dfs/demo/udsoncan/input/IntoRP/testcase.txt"
                        shutil.copy(testcase_src, testcase_dst)
                        logging.info(f"Copied testcase.txt from {testcase_src}")
                        copied = True

                    if "config.json" in files:
                        config_src = os.path.join(root, "config.json")
                        config_dst = "/home/mobase/dfs/demo/udsoncan/input/IntoRP/config.json"
                        shutil.copy(config_src, config_dst)
                        logging.info(f"Copied config.json from {config_src}")
                        copied = True

                if copied:
                    self._display("Files updated\nfrom USB.")
                else:
                    self._display("Files not found\non USB.")
                return

        self._display("No USB device found.")
    except Exception as e:
        logging.exception("Error copying files from USB")
        self._display("Error during\nfile copy.")
